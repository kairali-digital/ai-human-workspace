# SESSION START

1. Read the mode, classify the requested effect, then use the proportional read set in
   `AGENT-RULES.md`. Do not perform the older blanket read of every identity,
   compliance and task-state file for an ordinary read-only or local reversible task.
2. Read the installed version from `.ai-human/VERSION`. The deterministic local task
   command checks the writer lease itself. Inspect the lease manually only when a live
   task, manual controlled-state change or consequential path makes it relevant.
3. If the owner configured a native schedule, follow `UPDATE-SCHEDULER.md`. The native
   runner supplies its schedule ID and exact config hash; the lifecycle tool validates
   the confirmed host zone and calculates the due occurrence in the configured IANA
   zone before any release network check. When not due, use the last report quietly.
4. Report update details only when an update check actually ran or the user asked.
5. If a live task or writer lease exists, report `DEFERRED` and wait for a safe
   checkpoint. Do not alter controlled state behind the active writer.
6. If no live task or writer exists, an automatic update may continue only when the
   worker setting is ACTIVE and the release is owner-approved, immutable,
   hash-verified and explicitly backward-compatible. Otherwise wait for the existing
   approval path; an available release is not permission by itself.
7. Back up the current managed copy, apply only manifest-listed targets and preserve
   every user-owned state and setting. Automatically restore the backup on any
   failure.
8. Preserve all local company, role, fact, decision and task-state files. A reference
   pack update never rewrites a worker already copied from a starter.
9. Validate the worker. On failure, restore the backup and report the failed check.
10. On success, report the old version, new version, receipt location, preserved-state
    result and plain-language change summary. Attach that receipt to the user's
    evidence log without rewriting unrelated state.
11. Classify the user's request. For read-only work, answer directly without changing
    task state. For a clear local reversible request, run the deterministic task-start
    lifecycle path; it auto-generates an ID when needed and owns the lease and exact
    state format. Use the manual lease path only for consequential or other controlled
    changes the task command does not cover.
12. If the host exposes a trustworthy context-used signal, record it through the
    Context Guard. If not, keep the status `UNKNOWN`; never estimate a percentage from
    message count or files. When a checkpoint latch exists, accept no new work. In the
    intended new session, verify and consume the exact packet before continuing.
