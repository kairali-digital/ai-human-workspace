# START HERE - EVERYONE ELSE HOMEWORK

Use this pack for a meeting attendee who does not already have a named start or
homework page.

## Where this pack comes from

The preferred source is the protected public
`kairali-digital/ai-human-workspace` release v1.3.0. The complete
`kairali-company-rollout-1.3.0.zip` contains this homework, all approved people/setup
prompts and the two governed role skills. Public access needs no invitation or
collaborator seat, and the kit contains no live company work or secrets.

Ask the Setup Helper to get and verify the public kit. The employee does not use Git,
GitHub Desktop or a command. After the kit opens, use `homework/START-HERE.md` and copy
each required starter into a separate approved local work folder. Do not work inside
the public distribution repository.

## What they do

1. Required: `01-Email-Triage-AI-Human`.
2. Required: `02-Drive-Inventory-AI-Human`.
3. Optional after both: `03-LinkedIn-Draft-AI-Human-OPTIONAL`.

Each is a separate standalone local project. The employee does not use Terminal,
PowerShell, Command Prompt, Python, a CLI, Git or GitHub Desktop.

Future kit updates happen only at a safe checkpoint. Updating or removing the
reference kit does not modify or delete the employee's copied homework workers.

## Give the employee

- `EVERYONE-ELSE-AI-HUMAN-HOMEWORK-GUIDE.pdf`
- `EVERYONE-ELSE-AI-HUMAN-HOMEWORK-VIDEO.mp4`
- `EVERYONE-ELSE-AI-HUMAN-HOMEWORK-VIDEO-TRANSCRIPT.txt`
- `COPY-PASTE-PROMPTS.txt`
- the `AI-HUMAN-STARTERS` folder

No print quantity is stated because attendee headcount is not supplied.

## Facilitator rule

Start from the employee's visible screen. Give one action, wait, and verify its `DONE
WHEN`. If anything differs, use the complete Setup Helper prompt printed in the guide
and prompt file. The employee completes only an unavoidable click, company login,
account choice or permission. Never ask for a password or one-time code.

## Acceptance proof

- Email: the read-only 25-message pilot report, employee-approved daily time and time
  zone, ruled `BRIEF ONLY` or `BRIEF + SAFE FILING` mode, active daily automation and
  unchanged permanent Gmail filters.
- Drive: choose `TEST 25` or `FULL DRIVE INDEX`; every batch is at most 25 and
  checkpointed; index CSV, summary, cursor and scope coverage are visible; Drive unchanged.
- Optional LinkedIn: `LINKEDIN-DRAFTS.md`, marked `DRAFT - NOT PUBLISHED`.
- Each project says its workspace validator passed.

Do not accept “installed” or “connected” as completion. The visible local report and
the evidence log are the proof.
