# Your prompts — Anupam

## Your Iron Man mission

> You are learning to wear Codex like an Iron Man suit. You provide the mission and judgment. Codex performs approved work through a controlled autonomous loop.

Before this role mission, use `people/ALL-EMPLOYEES.md` to verify the common three-worker setup: Daily Email and Full Drive are required; Saturday LinkedIn is optional. Available in the kit is not live for you until the named proof passes.

Your mission is to close your Marketing rows in the Master Delegation Sheet. You choose the row and judge the result. Codex sorts, prepares, executes approved repeat work and records proof. Website and domain counts are not your responsibility.

**Your list:** Master Delegation Sheet — your own rows
**Where it is:** https://docs.google.com/spreadsheets/d/19MP_sEVE8JrC2hOMXbhhGDWTGCOcfoVTwLj0M422Di0/edit
**Open rows on your name today:** 318

Copy these one at a time. Do not run two at once.

---

## Every time you start

Open ChatGPT with the approved company account. Your work source is the Master Delegation Sheet, not website or domain files. The Setup Helper creates or opens your standalone local worker for durable state and connects the approved Google Drive app for your own rows; you do not need the shared repository. Never use Terminal. If the local worker or Sheet is missing, use the Setup Helper before continuing. Everything else is the same: one task at a time, execution batches of 25, proof at the end. Reading, counting, sorting or recording the complete assigned list is intake, not execution; follow the batch-unit rule in `people/ALL-EMPLOYEES.md`.

```
Here are my rows from the Master Delegation Sheet.
Read them. Do not suggest anything yet. Just tell me how many there are
and how many are still pending on my name.
```


---

## 1. Sort your list

```
Sort my rows into three groups:
A - the AI can do this for me now
B - I have to do it, but the AI can prepare it
C - only I can do it
One line on why, for each row. Do nothing else yet.
```

## 2. Find the repeat work

```
Look at group A. Which of these are the same job over and over?
Group them. Those are the ones we automate first.
```

## 3. Run one batch

```
Take 25 rows from the biggest group. Do them one at a time.
After each one write: what was done, and the proof.
Stop at 25.
```

## 4. What is blocked

```
List every row you could not finish, with the reason in one line.
```
---

## Every time you finish

```
I am closing this session.
1. Write my row into COMPLETED_LEDGER.md with the proof attached.
2. Remove that row from OPEN_REGISTER.md.
3. Show Abhilash the proof and next safe action. Wait for Abhilash to rule the cursor; Codex may record that ruling. Do not overwrite MASTER_CURSOR.md yourself.
4. List anything I left open, with the reason in one line.
Show me all of it before you save.
```

---

## The three rules

1. One task at a time. Say the number out loud before you start.
2. Never more than 25 in one go.
3. Nothing is done without proof. A saved setting is not proof.

**Stuck?** Open `people/SETUP-HELPER.md` and paste its complete message. Begin: **“I am stuck setting up my Kairali AI workspace. Be my Setup Helper.”** The helper performs safe setup work and writes the `OPEN_REGISTER.md` row if a human decision remains.
